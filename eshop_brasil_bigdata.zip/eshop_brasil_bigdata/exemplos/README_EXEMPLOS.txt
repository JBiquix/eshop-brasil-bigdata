Nesta pasta devem ser adicionados prints ou GIFs da aplicação funcionando.

Sugestões de imagens para colocar aqui:
1. Tela do dashboard
2. Tela de inserção de dados
3. Tela de consulta de dados
4. Tela de edição/exclusão
5. Tela de concatenação de dados

Essas imagens podem ser usadas no README.md e também na apresentação do trabalho.
